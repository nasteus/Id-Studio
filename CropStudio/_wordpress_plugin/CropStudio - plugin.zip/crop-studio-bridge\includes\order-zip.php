<?php
/**
 * WooCommerce Order Admin metabox, ZIP archive generator and photo management for Crop Studio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Crop_Studio_Order_ZIP {

	public function __construct() {
		// Afisare preview poze in detaliile comenzii (admin)
		add_action( 'woocommerce_after_order_itemmeta', array( $this, 'display_order_item_photos' ), 10, 3 );

		if ( class_exists( 'ZipArchive' ) ) {
			add_action( 'admin_init', array( $this, 'process_zip_download' ) );
			add_action( 'add_meta_boxes', array( $this, 'register_order_metabox' ) );
		}

		// Stergere poze la stergerea comenzii
		add_action( 'before_delete_post', array( $this, 'delete_order_uploads_on_post_delete' ) );
		add_action( 'woocommerce_before_delete_order', array( $this, 'delete_order_uploads_hpos' ) );
		add_action( 'admin_init', array( $this, 'handle_manual_delete_uploads' ) );
	}

	/**
	 * Inregistrare metabox in pagina de comanda WooCommerce (suporta CPT si HPOS)
	 */
	public function register_order_metabox() {
		$screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop_order' ) : 'shop_order';

		add_meta_box(
			'crop-studio-order-zip',
			'📸 Crop Studio - Fotografii Comandă',
			array( $this, 'render_order_metabox' ),
			$screen,
			'side',
			'high'
		);

		// Fallback pentru ecrane clasice shop_order
		if ( $screen !== 'shop_order' ) {
			add_meta_box(
				'crop-studio-order-zip',
				'📸 Crop Studio - Fotografii Comandă',
				array( $this, 'render_order_metabox' ),
				'shop_order',
				'side',
				'high'
			);
		}
	}

	/**
	 * Randare continut metabox comanda
	 */
	public function render_order_metabox( $post_or_order ) {
		$order = ( $post_or_order instanceof WC_Order ) ? $post_or_order : wc_get_order( $post_or_order );
		if ( ! $order ) {
			echo '<p>Comanda nu a putut fi identificată.</p>';
			return;
		}

		$order_id = $order->get_id();
		$has_uploads = false;
		$total_photos = 0;
		$total_copies = 0;

		foreach ( $order->get_items() as $item ) {
			$uploads = $item->get_meta( 'uploads' );
			if ( ! empty( $uploads ) && is_array( $uploads ) ) {
				$has_uploads = true;
				$total_photos += count( $uploads );
				foreach ( $uploads as $up ) {
					$total_copies += intval( ! empty( $up['quantity'] ) ? $up['quantity'] : 1 );
				}
			}
		}

		if ( ! $has_uploads ) {
			echo '<p style="color: #64748b; font-size: 13px;">Această comandă nu conține fotografii încărcate prin Crop Studio.</p>';
			return;
		}

		$wp_upload_dir = wp_upload_dir();
		$base_dir = $wp_upload_dir['basedir'] . '/woo-uploads';
		$base_url = $wp_upload_dir['baseurl'] . '/woo-uploads';
		$order_dir = $base_dir . '/' . $order_id . '/';
		$order_url = $base_url . '/' . $order_id . '/';
		$zip_file = $order_dir . 'comanda_' . $order_id . '_cropstudio.zip';
		$zip_url = $order_url . 'comanda_' . $order_id . '_cropstudio.zip';

		$nonce = wp_create_nonce( 'crop_studio_zip_' . $order_id );
		$generate_url = add_query_arg( array(
			'crop_studio_action' => 'stream_zip',
			'order_id'           => $order_id,
			'_wpnonce'           => $nonce,
		), admin_url( 'admin.php' ) );

		$delete_nonce = wp_create_nonce( 'crop_studio_delete_' . $order_id );
		$delete_url = add_query_arg( array(
			'crop_studio_action' => 'delete_order_files',
			'order_id'           => $order_id,
			'_wpnonce'           => $delete_nonce,
		), admin_url( 'admin.php' ) );

		echo '<div class="crop-studio-metabox-content">';
		echo '<div style="background: #f1f5f9; padding: 10px; border-radius: 6px; margin-bottom: 12px; font-size: 13px;">';
		echo '<div><strong>Fotografii unice:</strong> ' . esc_html( $total_photos ) . ' fișiere</div>';
		echo '<div><strong>Total tiraj (copii):</strong> ' . esc_html( $total_copies ) . ' bucăți</div>';
		echo '</div>';

		echo '<p><a href="' . esc_url( $generate_url ) . '" class="button button-primary button-large" style="width: 100%; text-align: center; height: 38px; line-height: 36px; font-weight: bold; background: #2563eb; border-color: #1d4ed8;">📥 Generează Arhivă ZIP</a></p>';

		if ( file_exists( $zip_file ) ) {
			$file_size_mb = round( filesize( $zip_file ) / ( 1024 * 1024 ), 2 );
			echo '<div style="margin-top: 10px; padding: 8px; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 6px; font-size: 12px; color: #065f46;">';
			echo '✅ Arhivă gata (' . $file_size_mb . ' MB).<br>';
			echo '<a href="' . esc_url( $zip_url ) . '" target="_blank" style="font-weight: bold; color: #059669; text-decoration: underline;">👉 Descarcă direct arhiva ZIP</a>';
			echo '</div>';
		}

		echo '<hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 15px 0;">';
		echo '<p style="margin-bottom: 0;"><a href="' . esc_url( $delete_url ) . '" onclick="return confirm(\'Ești sigur că vrei să ștergi definitiv fotografiile acestei comenzi de pe disc pentru eliberare spațiu?\');" style="color: #ef4444; font-size: 12px; text-decoration: none;">🗑️ Șterge definitiv fișierele de pe server</a></p>';
		echo '</div>';
	}

	/**
	 * Afisare fotografii cu previzualizare in detaliile fiecarui produs din comanda
	 */
	public function display_order_item_photos( $item_id, $item, $product ) {
		if ( ! is_admin() || ! ( $item instanceof WC_Order_Item_Product ) ) {
			return;
		}

		$uploads = $item->get_meta( 'uploads' );
		if ( empty( $uploads ) || ! is_array( $uploads ) ) {
			return;
		}

		$order_id = $item->get_order_id();
		$wp_upload_dir = wp_upload_dir();
		$base_url = $wp_upload_dir['baseurl'] . '/woo-uploads';
		$order_url = $base_url . '/' . $order_id . '/';
		$thumb_url = $order_url . '.thumb/';

		echo '<div class="crop-studio-order-item-photos" style="margin-top: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px;">';
		echo '<h4 style="margin: 0 0 10px 0; font-size: 13px; color: #1e293b;">🖼️ Fotografii decupate (' . count( $uploads ) . ' imagini):</h4>';
		echo '<div style="display: flex; flex-wrap: wrap; gap: 10px;">';

		foreach ( $uploads as $file_id => $info ) {
			$img_thumb = esc_url( $thumb_url . $file_id );
			$img_full = esc_url( $order_url . $file_id );
			$fn = esc_html( ! empty( $info['filename'] ) ? $info['filename'] : $file_id );
			$qty = intval( ! empty( $info['quantity'] ) ? $info['quantity'] : 1 );
			$finish = ! empty( $info['finish'] ) ? esc_html( $info['finish'] ) : '';

			echo '<div style="width: 110px; background: #fff; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px; text-align: center; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">';
			echo '<a href="' . $img_full . '" target="_blank" title="Click pentru rezoluție maximă">';
			echo '<img src="' . $img_thumb . '" alt="' . $fn . '" style="width: 100%; height: 75px; object-fit: cover; border-radius: 4px; display: block;" />';
			echo '</a>';
			echo '<div style="font-weight: 700; font-size: 12px; color: #0f172a; margin-top: 4px;">' . $qty . ' buc.</div>';
			if ( $finish ) {
				echo '<div style="font-size: 11px; color: #64748b;">' . $finish . '</div>';
			}
			echo '<div style="font-size: 10px; color: #94a3b8; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 2px;" title="' . $fn . '">' . $fn . '</div>';
			echo '</div>';
		}

		echo '</div>';
		echo '</div>';
	}

	/**
	 * Generare si streaming arhiva ZIP organizata pe directoare de marimi
	 */
	public function process_zip_download() {
		if ( ! isset( $_GET['crop_studio_action'] ) || $_GET['crop_studio_action'] !== 'stream_zip' ) {
			return;
		}

		$order_id = ! empty( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		if ( ! $order_id || ! wp_verify_nonce( $_GET['_wpnonce'], 'crop_studio_zip_' . $order_id ) ) {
			wp_die( 'Cerere neautorizată sau link expirat.' );
		}

		if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'edit_shop_orders' ) ) {
			wp_die( 'Nu aveți permisiuni suficiente.' );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_die( 'Comanda nu există.' );
		}

		@set_time_limit( 300 );
		@ini_set( 'memory_limit', '512M' );

		$wp_upload_dir = wp_upload_dir();
		$base_dir = $wp_upload_dir['basedir'] . '/woo-uploads';
		$order_dir = $base_dir . '/' . $order_id . '/';
		$zip_filename = 'comanda_' . $order_id . '_cropstudio.zip';
		$zip_path = $order_dir . $zip_filename;

		$zip = new ZipArchive();
		if ( $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) !== true ) {
			wp_die( 'Nu s-a putut crea fișierul ZIP pe disc.' );
		}

		$has_files = false;

		foreach ( $order->get_items() as $item_id => $item_data ) {
			$uploads = $item_data->get_meta( 'uploads' );
			if ( empty( $uploads ) || ! is_array( $uploads ) ) {
				continue;
			}

			// Nume folder in arhiva ex: 10x15-cm-Hartie-Lucioasa-Item-123
			$product_name = sanitize_title( $item_data->get_name() );
			$finish = sanitize_title( $item_data->get_meta( 'Finisaj hartie' ) );
			$dir_name = $product_name . ( $finish ? '-' . $finish : '' ) . '-#' . $item_id;
			$zip->addEmptyDir( $dir_name );

			foreach ( $uploads as $file_id => $info ) {
				$file_on_disk = $order_dir . $file_id;
				if ( ! file_exists( $file_on_disk ) ) {
					continue;
				}

				$orig_name = ! empty( $info['filename'] ) ? $info['filename'] : $file_id;
				$qty = intval( ! empty( $info['quantity'] ) ? $info['quantity'] : 1 );
				$path_info = pathinfo( $orig_name );
				$base_name = sanitize_title( $path_info['filename'] );
				$ext = ! empty( $path_info['extension'] ) ? $path_info['extension'] : 'jpg';

				// Format nume fisier in arhiva: photo_1_copii-3.jpg
				$zip_entry_name = sprintf( '%s/%s_copii-%d.%s', $dir_name, $base_name, $qty, $ext );
				$zip->addFile( $file_on_disk, $zip_entry_name );
				$has_files = true;
			}
		}

		$zip->close();

		if ( ! $has_files || ! file_exists( $zip_path ) ) {
			wp_die( 'Nu au fost găsite fișiere foto valide pentru a genera arhiva.' );
		}

		// Descarcare directa fisier ZIP
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $zip_filename . '"' );
		header( 'Content-Length: ' . filesize( $zip_path ) );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
		readfile( $zip_path );
		exit;
	}

	/**
	 * Stergere manuala fisiere comanda
	 */
	public function handle_manual_delete_uploads() {
		if ( ! isset( $_GET['crop_studio_action'] ) || $_GET['crop_studio_action'] !== 'delete_order_files' ) {
			return;
		}

		$order_id = ! empty( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		if ( ! $order_id || ! wp_verify_nonce( $_GET['_wpnonce'], 'crop_studio_delete_' . $order_id ) ) {
			wp_die( 'Cerere neautorizată.' );
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'Nu aveți permisiuni suficiente.' );
		}

		$this->delete_order_directory( $order_id );

		$redirect_back = wp_get_referer() ? wp_get_referer() : admin_url( 'edit.php?post_type=shop_order' );
		wp_safe_redirect( $redirect_back );
		exit;
	}

	public function delete_order_uploads_on_post_delete( $post_id ) {
		if ( 'shop_order' === get_post_type( $post_id ) ) {
			$this->delete_order_directory( $post_id );
		}
	}

	public function delete_order_uploads_hpos( $order ) {
		if ( $order && method_exists( $order, 'get_id' ) ) {
			$this->delete_order_directory( $order->get_id() );
		}
	}

	private function delete_order_directory( $order_id ) {
		$wp_upload_dir = wp_upload_dir();
		$order_dir = $wp_upload_dir['basedir'] . '/woo-uploads/' . $order_id;

		if ( file_exists( $order_dir ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
			$fs = new WP_Filesystem_Direct( array() );
			$fs->delete( $order_dir, true );
		}
	}
}

new Crop_Studio_Order_ZIP();
